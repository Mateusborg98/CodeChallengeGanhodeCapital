package br.com.nubank.capitalgain.domain.model;

public enum OperationType {
	BUY,
	SELL
}
